import React from 'react'

const Rodape = () => {
  return (
    <div style={{width: '100%'}} className='bg-secondary text-white text-center position-fixed bottom-0'>
      <p>Rodapé</p>
    </div>
  )
}

export default Rodape